# hereFromCpp

This is a repo which contains basic declaration and syntax used in different languages

c++ -> core Java (core java + collections framework)
<br>
c++ -> JavaScript (pure javascript)
<br>
lego blocks that are used to solve difficult ds/algo problems