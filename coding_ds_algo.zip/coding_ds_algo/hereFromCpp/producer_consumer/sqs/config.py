QUEUE_URL = 'https://sqs.ap-south-1.amazonaws.com/050781053123/mydata-ingestor-dev'
ACCESS_KEY = 'AKIAQXUWJMDBW255MKUK'
SECRET_KEY = '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'
REGION_NAME = 'ap-south-1'

gmail_user = "jubinkumarsoni@gmail.com"
gmail_pwd = "vshsvoivbdalwnuf"

to_email = "znnsoni1993@yahoo.com"