#include <iostream>
#include <thread>
#include <string>


//Both thread starts simutaneously executing tasks like parallel resistor in a circuit
//join to main method just ensures that main method waits untill the thread gets executed completely
//Note : compile with clang++ -std=c++11 multi_thread1.cpp
void thread_function(std::string str)
{
    for(int i=0;i<=10;i++)
    {
        std::cout << str << "=> " << i << std::endl;
    }
}


int main()  
{
    std::thread threadObj1(thread_function,"From thread1");
    std::thread threadObj2(thread_function,"From thread2");
 
    if(threadObj1.get_id() != threadObj2.get_id())
        std::cout<<"Both Threads have different IDs"<<std::endl;
 
        std::cout<<"From Main Thread :: ID of Thread 1 = "<<threadObj1.get_id()<<std::endl;    
    std::cout<<"From Main Thread :: ID of Thread 2 = "<<threadObj2.get_id()<<std::endl;    
 
    threadObj1.join();
    threadObj2.join();   
    return 0;
}