#include <iostream>
#include <thread>
#include <string>


//Both thread starts simutaneously executing tasks like parallel resistor in a circuit
//join to main method just ensures that main method waits untill the thread gets executed completely
//Note : compile with clang++ -std=c++11 multi_thread2.cpp
//if a thread is declared then atleast it should be joined first and then 
//can be removed by checking if(th.joinable())=> th.detach()
//On detaching a thread...thread runs in background and main method won't wait for detached thread to be finished 
/*
Be careful with calling detach() and join() on Thread Handles

Case 1: Never call join() or detach() on std::thread object with no associated executing thread

std::thread threadObj( (WorkerThread()) );
threadObj.join();
threadObj.join(); // It will cause Program to Terminate

When a join() function is called on an thread object, then when this joins thread to function
In case again join() function is called on such object then it will cause the program to Terminate.

Similarly calling detach() makes the std::thread object not linked with any function. 
In that case calling detach function twice on an std::thread object will cause the program to terminate.

std::thread threadObj( (WorkerThread()) );
threadObj.detach();
threadObj.detach(); // It will cause Program to Terminate
Therefore, before calling join() or detach() we should check if thread is join-able every time i.e.
*/
void thread_function(std::string str)
{
    for(int i=0;i<=10;i++)
    {
        std::cout << str << "=> " << i << std::endl;
    }
}


int main()  
{
    std::thread threadObj1(thread_function,"From thread1");
    std::thread threadObj2(thread_function,"From thread2");
 
    if(threadObj1.get_id() != threadObj2.get_id())
        std::cout<<"Both Threads have different IDs"<<std::endl;
 
        std::cout<<"From Main Thread :: ID of Thread 1 = "<<threadObj1.get_id()<<std::endl;    
    std::cout<<"From Main Thread :: ID of Thread 2 = "<<threadObj2.get_id()<<std::endl;    
 
    threadObj1.join();
    if(threadObj1.joinable())
    {
        std::cout<<"Detaching Thread "<<std::endl;
        threadObj1.detach();
    }
    threadObj2.join();   
    return 0;
}