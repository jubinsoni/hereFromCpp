#include <iostream>
#include <thread>

//How to pass address and manipulate value at address in threading
/*Output :
    In Main Thread : Before Thread Start x = 9
    Inside Thread x = 10
    In Main Thread : After Thread Joins x = 10
*/
void threadCallback(int &x)
{
    int *ptr = &x;
    *ptr = *ptr + 1;
    std::cout<<"Inside Thread x = "<<x<<std::endl;
}

int main()
{
    int x = 9;
    std::cout<<"In Main Thread : Before Thread Start x = "<<x<<std::endl;
    std::thread threadObj(threadCallback,std::ref(x));
    threadObj.join();
    std::cout<<"In Main Thread : After Thread Joins x = "<<x<<std::endl;
    return 0;
}