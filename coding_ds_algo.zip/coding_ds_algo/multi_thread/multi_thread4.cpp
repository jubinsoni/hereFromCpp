#include <iostream>
#include <thread>

//Need for locks? and simulation of a race condition
void threadCallback(int &x)
{
    int *ptr = &x;
    for(int i=0;i<10000;i++)
    {
        *ptr = *ptr + 1;
    }
}

int main()
{
    int x = 0;
    std::thread threadObj1(threadCallback,std::ref(x));
    std::thread threadObj2(threadCallback,std::ref(x));
    std::cout<<"Both threads tries to access same address &x and";
    std::cout<<"value of when 2 threads simultaneously changes value at &x x = "<<x<<std::endl;
    std::cout<<"So each program run value of x is different"<<std::endl;
    std::cout<<"To cure this we have to use locks and unlock on shared resources"<<std::endl;
    threadObj1.join();
    threadObj2.join();
    return 0;
}